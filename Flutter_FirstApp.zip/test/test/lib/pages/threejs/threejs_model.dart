import '/flutter_flow/flutter_flow_util.dart';
import 'threejs_widget.dart' show ThreejsWidget;
import 'package:flutter/material.dart';

class ThreejsModel extends FlutterFlowModel<ThreejsWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
